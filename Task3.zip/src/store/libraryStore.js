import { create } from 'zustand';

// Utility for generating IDs
const newId = () => Math.random().toString(36).substr(2, 9);

export const useLibrary = create((set, get) => ({
  books: [
    { id: newId(), title: 'The Hobbit', author: 'J.R.R. Tolkien', categories: ['Fantasy'], status: 'available' },
    { id: newId(), title: 'Atomic Habits', author: 'James Clear', categories: ['Self-help'], status: 'borrowed', borrowedBy: 'Ali' },
  ],
  categories: ['Fantasy', 'Self-help'],
  history: [],

  // Add a new book
  addBook: (book) => set((state) => ({
    books: [...state.books, { id: newId(), status: 'available', ...book }]
  })),

  // Update a book
  updateBook: (id, updates) => set((state) => ({
    books: state.books.map(b => b.id === id ? { ...b, ...updates } : b)
  })),

  // Delete a book
  deleteBook: (id) => set((state) => ({
    books: state.books.filter(b => b.id !== id)
  })),

  // Borrow a book
  borrowBook: (id, borrower) => set((state) => {
    const updated = state.books.map(b =>
      b.id === id ? { ...b, status: 'borrowed', borrowedBy: borrower } : b
    );
    return {
      books: updated,
      history: [...state.history, { id: newId(), bookId: id, borrower, borrowedAt: new Date().toISOString() }]
    };
  }),

  // Return a book
  returnBook: (id) => set((state) => {
    const updated = state.books.map(b =>
      b.id === id ? { ...b, status: 'available', borrowedBy: null } : b
    );
    const history = state.history.map(h =>
      h.bookId === id && !h.returnedAt ? { ...h, returnedAt: new Date().toISOString() } : h
    );
    return { books: updated, history };
  }),

  // Add a category
  addCategory: (name) => set((state) => ({
    categories: [...state.categories, name]
  })),

  // Remove a category
  removeCategory: (name) => set((state) => ({
    categories: state.categories.filter(c => c !== name)
  })),
}));
