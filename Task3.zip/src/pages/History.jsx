import { useLibrary } from '../store/libraryStore';

export default function History() {
  const { history, books } = useLibrary();

  const getBookTitle = (id) => {
    const book = books.find(b => b.id === id);
    return book ? book.title : 'Unknown Book';
  };

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">📖 Borrowing History</h2>

      {history.length === 0 && (
        <p className="text-gray-600">No borrowing history yet.</p>
      )}

      <ul className="space-y-3">
        {history.slice().reverse().map((h) => (
          <li 
            key={h.id} 
            className="bg-white shadow-md p-4 rounded-lg"
          >
            <p>
              <b className="text-blue-600">{h.borrower}</b> borrowed 
              <span className="font-semibold"> "{getBookTitle(h.bookId)}"</span> 
              on <span className="text-gray-700">{new Date(h.borrowedAt).toLocaleDateString()}</span>
            </p>
            <p className="text-sm text-gray-600 mt-1">
              {h.returnedAt 
                ? <>✅ Returned on {new Date(h.returnedAt).toLocaleDateString()}</>
                : "⏳ Still borrowed"}
            </p>
          </li>
        ))}
      </ul>
    </div>
  );
}
