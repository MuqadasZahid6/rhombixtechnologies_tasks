import { useLibrary } from '../store/libraryStore';

export default function Dashboard() {
  const { books, categories, history } = useLibrary();

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">📊 Dashboard</h2>

      {/* Stats Section */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        <div className="bg-white shadow-md rounded-lg p-6 text-center">
          <h3 className="text-lg font-semibold">Total Books</h3>
          <p className="text-2xl font-bold text-blue-600">{books.length}</p>
        </div>

        <div className="bg-white shadow-md rounded-lg p-6 text-center">
          <h3 className="text-lg font-semibold">Categories</h3>
          <p className="text-2xl font-bold text-green-600">{categories.length}</p>
        </div>

        <div className="bg-white shadow-md rounded-lg p-6 text-center">
          <h3 className="text-lg font-semibold">Borrowed Books</h3>
          <p className="text-2xl font-bold text-red-600">
            {books.filter(b => b.status === 'borrowed').length}
          </p>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white shadow-md rounded-lg p-6">
        <h3 className="text-lg font-semibold mb-4">📌 Recent Activity</h3>

        {history.length === 0 && (
          <p className="text-gray-600">No activity yet.</p>
        )}

        <ul className="space-y-3">
          {history.slice(-5).reverse().map((h) => (
            <li 
              key={h.id} 
              className="border-b pb-2 last:border-b-0"
            >
              <span className="font-semibold text-blue-600">{h.borrower}</span>{" "}
              {h.returnedAt 
                ? <>returned <span className="font-semibold">"{books.find(b => b.id === h.bookId)?.title}"</span></>
                : <>borrowed <span className="font-semibold">"{books.find(b => b.id === h.bookId)?.title}"</span></>
              }
              {" "}on {new Date(h.borrowedAt).toLocaleDateString()}
              {h.returnedAt && (
                <> (returned {new Date(h.returnedAt).toLocaleDateString()})</>
              )}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
