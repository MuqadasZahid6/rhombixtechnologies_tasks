import { useState } from 'react';
import { useLibrary } from '../store/libraryStore';

export default function Categories() {
  const { categories, addCategory, removeCategory } = useLibrary();
  const [name, setName] = useState('');

  const handleAdd = (e) => {
    e.preventDefault();
    if (!name.trim()) return;
    addCategory(name);
    setName('');
  };

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">🏷 Categories</h2>

      {/* Form to add category */}
      <form onSubmit={handleAdd} className="flex gap-2 mb-6">
        <input
          type="text"
          placeholder="New category"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="border p-2 flex-1 rounded"
        />
        <button 
          type="submit"
          className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
        >
          Add
        </button>
      </form>

      {/* Category List */}
      <ul className="space-y-2">
        {categories.map(c => (
          <li 
            key={c} 
            className="bg-white shadow flex justify-between items-center p-3 rounded"
          >
            <span>{c}</span>
            <button 
              onClick={() => removeCategory(c)} 
              className="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600"
            >
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
