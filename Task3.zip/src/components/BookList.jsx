import { useLibrary } from '../store/libraryStore';

export default function BookList() {
  const { books, borrowBook, returnBook, deleteBook } = useLibrary();

  if (books.length === 0) {
    return <p className="text-gray-600">No books yet. Add some!</p>;
  }

  return (
    <div className="grid gap-4">
      {books.map((book) => (
        <div
          key={book.id}
          className="bg-white shadow-md rounded-lg p-4 flex flex-col sm:flex-row justify-between"
        >
          <div>
            <h3 className="text-lg font-bold">{book.title}</h3>
            <p className="italic">{book.author}</p>
            <p className="text-sm text-gray-600">
              Categories: {book.categories.join(', ')}
            </p>
            <p className="text-sm">
              Status:{' '}
              <span
                className={
                  book.status === 'available'
                    ? 'text-green-600'
                    : 'text-red-600'
                }
              >
                {book.status}
              </span>
            </p>
          </div>

          <div className="mt-3 sm:mt-0 flex gap-2 items-start sm:items-center">
            {book.status === 'available' ? (
              <button
                onClick={() => {
                  const name = prompt("Enter borrower's name:");
                  if (name) borrowBook(book.id, name);
                }}
                className="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600"
              >
                Borrow
              </button>
            ) : (
              <button
                onClick={() => returnBook(book.id)}
                className="px-3 py-1 bg-green-500 text-white rounded hover:bg-green-600"
              >
                Return
              </button>
            )}

            <button
              onClick={() => deleteBook(book.id)}
              className="px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600"
            >
              Delete
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
