export default function SearchBar({ query, setQuery, category, setCategory, categories }) {
    return (
      <div style={{marginBottom:"20px"}}>
        <input
          type="text"
          placeholder="Search by title or author..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <select value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="">All Categories</option>
          {categories.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
        <button onClick={() => { setQuery(''); setCategory(''); }}>Clear</button>
      </div>
    );
  }
  