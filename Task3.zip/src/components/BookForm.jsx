import { useState } from 'react';
import { useLibrary } from '../store/libraryStore';

export default function BookForm() {
  const { addBook, categories } = useLibrary();
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [cat, setCat] = useState(categories[0] || 'General');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title.trim() || !author.trim()) return;

    addBook({ title, author, categories: [cat] });
    setTitle('');
    setAuthor('');
  };

  return (
    <form 
      onSubmit={handleSubmit} 
      className="bg-white shadow-md rounded-lg p-4 mb-6"
    >
      <h3 className="text-lg font-semibold mb-4">➕ Add a New Book</h3>

      <input
        type="text"
        placeholder="Book Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        className="border p-2 w-full mb-3 rounded"
        required
      />

      <input
        type="text"
        placeholder="Author"
        value={author}
        onChange={(e) => setAuthor(e.target.value)}
        className="border p-2 w-full mb-3 rounded"
        required
      />

      <select
        value={cat}
        onChange={(e) => setCat(e.target.value)}
        className="border p-2 w-full mb-3 rounded"
      >
        {categories.map(c => <option key={c}>{c}</option>)}
      </select>

      <button 
        type="submit"
        className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
      >
        Add Book
      </button>
    </form>
  );
}
