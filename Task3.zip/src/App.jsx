import { NavLink, Routes, Route } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import Books from './pages/Books';
import Categories from './pages/Categories';
import History from './pages/History';

export default function App() {
  const linkClasses =
    'px-2 py-1 rounded hover:bg-blue-700 transition-colors duration-200';

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Navbar */}
      <nav className="bg-blue-600 text-white p-4 flex flex-wrap gap-4">
        <NavLink
          to="/"
          end
          className={({ isActive }) =>
            isActive ? `${linkClasses} bg-blue-800` : linkClasses
          }
        >
          Dashboard
        </NavLink>
        <NavLink
          to="/books"
          className={({ isActive }) =>
            isActive ? `${linkClasses} bg-blue-800` : linkClasses
          }
        >
          Books
        </NavLink>
        <NavLink
          to="/categories"
          className={({ isActive }) =>
            isActive ? `${linkClasses} bg-blue-800` : linkClasses
          }
        >
          Categories
        </NavLink>
        <NavLink
          to="/history"
          className={({ isActive }) =>
            isActive ? `${linkClasses} bg-blue-800` : linkClasses
          }
        >
          History
        </NavLink>
      </nav>

      {/* Page Content */}
      <div className="p-6">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/books" element={<Books />} />
          <Route path="/categories" element={<Categories />} />
          <Route path="/history" element={<History />} />
        </Routes>
      </div>
    </div>
  );
}
